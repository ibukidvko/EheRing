EiheiLing V1.0 Lite Portable

All settings, followed streamers, avatar cache, and logs are stored in the
Data folder next to the application.

To move the application to another computer, copy the entire extracted folder.
Extract the ZIP before running EiheiLing.exe.

Microsoft .NET 10 Desktop Runtime x64 is required.
